const http = require("http");
const url = require("url");
const fs = require("fs");
const path = require("path");

const PORT = 3000;

const booksFile = path.join(__dirname, "books.json");
const logsDir = path.join(__dirname, "logs");
const logFile = path.join(logsDir, "access.log");
const publicDir = path.join(__dirname, "public");

// ==================================================
// R4 - Create logs directory if it does not exist
// ==================================================

if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir);
}

// ==================================================
// R4 - Callback style
// ==================================================

function readBooksCallback(callback) {
    fs.readFile(booksFile, "utf8", (err, data) => {
        if (err) {
            callback(err, null);
            return;
        }

        try {
            const books = JSON.parse(data);
            callback(null, books);
        } catch (error) {
            callback(error, null);
        }
    });
}

function writeBooksCallback(books, callback) {
    const json = JSON.stringify(books, null, 2);

    fs.writeFile(booksFile, json, "utf8", (err) => {
        if (err) {
            callback(err);
            return;
        }

        callback(null);
    });
}

// ==================================================
// R4 - Async/Await style
// ==================================================

async function readBooksAsync() {
    const data = await fs.promises.readFile(
        booksFile,
        "utf8"
    );

    return JSON.parse(data);
}

async function writeBooksAsync(books) {
    const json = JSON.stringify(books, null, 2);

    await fs.promises.writeFile(
        booksFile,
        json,
        "utf8"
    );
}

// ==================================================
// R5 - MIME types
// ==================================================

const mimeTypes = {
    ".html": "text/html",
    ".css": "text/css",
    ".js": "text/javascript",
    ".json": "application/json",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".svg": "image/svg+xml"
};

// ==================================================
// Create HTTP server
// ==================================================

const server = http.createServer((req, res) => {

    // ==================================================
    // R4 - Access log
    // ==================================================

    const log =
        `${new Date().toISOString()} ${req.method} ${req.url}\n`;

    fs.appendFile(logFile, log, "utf8", (err) => {
        if (err) {
            console.error("Cannot write log:", err);
        }
    });

    // ==================================================
    // Parse URL
    // ==================================================

    const parsedUrl = url.parse(req.url, true);

    const pathname = parsedUrl.pathname;
    const query = parsedUrl.query;

    // ==================================================
    // R2 - GET /
    // ==================================================

    if (req.method === "GET" && pathname === "/") {

        res.writeHead(200, {
            "Content-Type": "text/html"
        });

        res.end(`
            <html>
                <head>
                    <title>BookNest</title>
                </head>

                <body>
                    <h1>Welcome to BookNest</h1>
                    <p>Node.js HTTP Server</p>
                </body>
            </html>
        `);

        return;
    }

    // ==================================================
    // R2 - GET /about
    // ==================================================

    if (req.method === "GET" && pathname === "/about") {

        res.writeHead(200, {
            "Content-Type": "text/html"
        });

        res.end(`
            <html>
                <body>
                    <h1>About BookNest</h1>
                    <p>This is a Node.js lab.</p>
                </body>
            </html>
        `);

        return;
    }

    // ==================================================
    // R2 + R3 - GET /api/books
    // ==================================================

    if (req.method === "GET" && pathname === "/api/books") {

        readBooksCallback((err, books) => {

            if (err) {

                res.writeHead(500, {
                    "Content-Type": "application/json"
                });

                res.end(JSON.stringify({
                    error: "Cannot read books.json"
                }));

                return;
            }

            let result = books;

            // ------------------------------------------
            // R3 - Filter by category
            // Example:
            // /api/books?category=IT
            // ------------------------------------------

            if (query.category) {

                result = result.filter(
                    book => book.category === query.category
                );
            }

            // ------------------------------------------
            // R3 - Limit results
            // Example:
            // /api/books?limit=2
            // ------------------------------------------

            if (query.limit) {

                const limit = Number(query.limit);

                if (!isNaN(limit) && limit >= 0) {

                    result = result.slice(0, limit);
                }
            }

            res.writeHead(200, {
                "Content-Type": "application/json"
            });

            res.end(JSON.stringify(result));
        });

        return;
    }

    // ==================================================
    // R3 + R4 - POST /api/books
    // ==================================================

    if (req.method === "POST" && pathname === "/api/books") {

        let body = "";

        // ------------------------------------------
        // Receive request body
        // ------------------------------------------

        req.on("data", chunk => {
            body += chunk;
        });

        // ------------------------------------------
        // Request body completed
        // ------------------------------------------

        req.on("end", async () => {

            try {

                // Convert JSON string to object
                const newBook = JSON.parse(body);

                // Read current books
                const books = await readBooksAsync();

                // Generate new ID
                newBook.id = books.length + 1;

                // Add new book
                books.push(newBook);

                // Save to books.json
                await writeBooksAsync(books);

                // Return 201 Created
                res.writeHead(201, {
                    "Content-Type": "application/json"
                });

                res.end(JSON.stringify(newBook));

            } catch (error) {

                console.error(error);

                res.writeHead(400, {
                    "Content-Type": "application/json"
                });

                res.end(JSON.stringify({
                    error: "Invalid JSON or file error"
                }));
            }
        });

        return;
    }

    // ==================================================
    // R3 - Unsupported method
    // ==================================================

    if (pathname === "/api/books") {

        res.writeHead(405, {
            "Content-Type": "application/json"
        });

        res.end(JSON.stringify({
            error: "Method Not Allowed"
        }));

        return;
    }

    // ==================================================
    // R5 - Download file
    // ==================================================

    if (req.method === "GET" && pathname === "/download") {

        const filePath = path.join(
            publicDir,
            "image.jpg"
        );

        fs.readFile(filePath, (err, data) => {

            if (err) {

                res.writeHead(404, {
                    "Content-Type": "text/plain"
                });

                res.end("File not found");

                return;
            }

            res.writeHead(200, {
                "Content-Type": "image/jpeg",
                "Content-Disposition":
                    'attachment; filename="image.jpg"'
            });

            res.end(data);
        });

        return;
    }

    // ==================================================
    // R5 - Serve static files
    // ==================================================

    if (req.method === "GET") {

        // Remove leading "/" from pathname
        const requestedFile = pathname.startsWith("/")
            ? pathname.substring(1)
            : pathname;

        const filePath = path.join(
            publicDir,
            requestedFile
        );

        // Security check:
        // Prevent accessing files outside public folder
        if (!filePath.startsWith(publicDir)) {

            res.writeHead(403, {
                "Content-Type": "text/html"
            });

            res.end("<h1>403 - Forbidden</h1>");

            return;
        }

        fs.readFile(filePath, (err, data) => {

            if (err) {

                res.writeHead(404, {
                    "Content-Type": "text/html"
                });

                res.end(`
                    <h1>404 - File Not Found</h1>
                `);

                return;
            }

            // Get file extension
            const ext = path.extname(filePath).toLowerCase();

            // Get MIME type
            const contentType =
                mimeTypes[ext] ||
                "application/octet-stream";

            res.writeHead(200, {
                "Content-Type": contentType
            });

            res.end(data);
        });

        return;
    }

    // ==================================================
    // R2 - 404
    // ==================================================

    res.writeHead(404, {
        "Content-Type": "text/html"
    });

    res.end(`
        <h1>404 - Page Not Found</h1>
    `);
});

// ==================================================
// Start server
// ==================================================

server.listen(PORT, () => {

    console.log(
        `Server running at http://localhost:${PORT}`
    );
});